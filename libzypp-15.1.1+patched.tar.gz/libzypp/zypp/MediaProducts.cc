/*---------------------------------------------------------------------\
|                          ____ _   __ __ ___                          |
|                         |__  / \ / / . \ . \                         |
|                           / / \ V /|  _/  _/                         |
|                          / /__ | | | | | |                           |
|                         /_____||_| |_| |_|                           |
|                                                                      |
\---------------------------------------------------------------------*/


#undef ZYPP_BASE_LOGGER_LOGGROUP
#define ZYPP_BASE_LOGGER_LOGGROUP "zypp"

#include "zypp/MediaProducts.h"

using namespace std;

namespace zypp
{

// template<class _OutputIterator>
// void productsInMedia( const Url & url_r, _OutputIterator result )


} // ns zypp

// vim: set ts=2 sts=2 sw=2 et ai:
