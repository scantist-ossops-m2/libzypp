#include "BaseImpl.h"

using namespace std;

namespace jk
{


  Base::BaseImpl::BaseImpl()
  {}


} // ns zypp

// vim: set ts=2 sts=2 sw=2 et ai:

